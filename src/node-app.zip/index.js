const express = require('express');
const app = express();

const PORT = process.env.PORT || 80;

// Variável para contar os segundos desde o início do servidor
let counter = 0;

// Atualiza o contador de segundos a cada segundo
setInterval(() => {
    counter++;
}, 1000);

// Middleware para servir arquivos estáticos
app.use(express.static('public'));

// Rota principal que inclui um contador de segundos e um botão
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Servidor Node</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    margin-top: 50px;
                }
                button {
                    padding: 10px 20px;
                    font-size: 16px;
                    margin-top: 20px;
                    cursor: pointer;
                    background-color: #007BFF;
                    color: white;
                    border: none;
                    border-radius: 5px;
                }
                button:hover {
                    background-color: #0056b3;
                }
            </style>
        </head>
        <body>
            <h1>Horario do servidor Node</h1>
            <p>Elapsed time: <span id="counter">${counter}</span> seconds.</p>
            <button onclick="window.location.href='/datetime'">Horario do Servidor</button>
        </body>
        </html>
    `);
});

// Rota /datetime que retorna a hora do servidor
app.get('/datetime', (req, res) => {
    const now = new Date();
    res.json({ datetime: now.toISOString() });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
